package com.fhn.emm;

public class EMMTags {
	public static String complexType = "complexType";
	public static String element = "element";
	public static String annotation = "annotation";
	public static String documentation = "documentation";
	public static String attributeGroup = "attributeGroup";
	public static String enumeration = "enumeration";
	public static String attribute = "attribute";
	
	//cantrol statements
	public static String sequence = "sequence";
	public static String simpleContent = "simpleContent";
	public static String extension = "extension";
	public static String restriction = "restriction";
	public static String choice = "choice";
	
	public static String xmlns = "xmlns";
	public static String substitutionGroup = "substitutionGroup";
	public static String abstractType = "abstract";
	public static String block = "block";
	public static String form = "form";
	public static String id = "id";
	public static String namespace = "namespace";
	public static String version = "version";
}
