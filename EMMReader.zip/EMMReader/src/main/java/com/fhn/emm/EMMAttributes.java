package com.fhn.emm;

public class EMMAttributes {
	public static String NAME = "name";
	public static String value = "value";
	public static String type = "type";
	public static String minOccurs = "minOccurs";
	public static String maxOccurs = "maxOccurs";
	public static String ref = "ref";
	public static String use = "use";
	public static String defaultType = "default";
	public static String fixed = "fixed";
	public static String targetNamespace = "targetNamespace";
	public static String xmlns = "xmlns";
	public static String substitutionGroup = "substitutionGroup";
	public static String abstractType = "abstract";
	public static String block = "block";
	public static String form = "form";
	public static String id = "id";
	public static String namespace = "namespace";
	public static String version = "version";
	public static String source = "source";
	
	
	
}
