package com.fhn.emm;

public class EMMSimpleTypes {
	
	
	public static String anyType = "anyType";
	public static String anySimpleType = "anySimpleType";
	public static String durationType = "durationType";
	public static String dateTimeType = "dateTimeType";
	public static String timeType = "time";
	public static String dateType = "date";
	public static String gYearMonth = "gYearMonth";
	public static String gYear = "gYear";
	public static String gMonthDay = "gMonthDay";
	public static String gDay = "gDay";
	public static String gMonth = "gMonth";
	public static String stringType = "string";
	public static String booleanType = "boolean";
	public static String base64Binary = "base64Binary";
	public static String hexBinary = "hexBinary";
	public static String floatType = "float";
	public static String decimalType = "decimal";
	public static String doubleType = "double";
	public static String anyURI = "anyURI";
	public static String QName = "QName";
	public static String NOTATION = "NOTATION";
	public static String normalizedString = "normalizedString";
	public static String integerType = "integer";
	public static String token = "token";
	public static String nonPositiveInteger = "nonPositiveInteger";
	public static String longType = "long";
	public static String nonNegativeInteger = "nonNegativeInteger";
	public static String language = "language";
	public static String Name = "Name";
	public static String NMTOKEN = "NMTOKEN";
	public static String negativeInteger = "negativeInteger";
	public static String intType = "int";
	public static String unsignedLong = "unsignedLong";
	public static String positiveInteger = "positiveInteger";
	public static String NCName = "NCName";
	public static String NMTOKENS = "NMTOKENS";
	public static String shortType = "short";
	public static String unsignedInt = "unsignedInt";
	public static String IDType = "ID";
	public static String IDREF = "IDREF";
	public static String ENTITY = "ENTITY";
	public static String byteType = "byte";
	public static String unsignedShort = "unsignedShort";
	public static String IDREFS = "IDREFS";
	public static String ENTITIES = "ENTITIES";
	public static String unsignedByte = "unsignedByte";

}
