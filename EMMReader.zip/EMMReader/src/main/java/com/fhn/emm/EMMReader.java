/**
 * 
 */
package com.fhn.emm;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
/**
 * @author User
 *
 */
public class EMMReader {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	      try {
	         File inputFile = new File("C:\\Users\\User\\Downloads\\gws_schemas\\gws_schemas\\OTA\\OTA_AirCommonTypes.xsd");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
              NamedNodeMap namedNodMap = doc.getDocumentElement().getAttributes();
              String XMLSchemaPrefix ="";
              String XMLSchemaNaeSpace ="";
              //Find namespaces and prefixes
              for(int i=0; i<namedNodMap.getLength();i++) {
            	  Node namespaceNode= namedNodMap.item(i);
            	  System.out.println("namespaceNode "+namespaceNode.getNodeValue());
            	  if(namespaceNode.getNodeValue().equals("http://www.w3.org/2001/XMLSchema")) {
            		  XMLSchemaNaeSpace = namespaceNode.getNodeName();
            		  System.out.println("XMLSchemaPrefix "+XMLSchemaNaeSpace);
            		  if(XMLSchemaNaeSpace.contains(":")) {
            			  XMLSchemaPrefix = XMLSchemaNaeSpace.substring(XMLSchemaNaeSpace.indexOf(":")+1);
            		  }
            	  }
            	  
              }
              System.out.println("XMLSchemaPrefix #" + XMLSchemaPrefix);
              System.out.println("namedNodMap :" + namedNodMap.getNamedItem("targetNamespace"));
              //namedNodMap.item(0)
	         System.out.println("----------------------------");
	         
	         NodeList nList = doc.getElementsByTagName(XMLSchemaPrefix+":complexType");
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            
	            	Element eElement = (Element) nNode;
	            	System.out.println("eElement"+eElement.getFirstChild());
	               System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	         }
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }

}
